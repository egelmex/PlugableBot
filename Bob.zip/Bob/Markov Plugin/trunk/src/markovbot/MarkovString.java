/*
 * MarkovString.java
 *
 * Created on 06 October 2007, 15:09
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package markovbot;

import java.util.*;
import java.io.*;
/**
 *
 * @author Administrator
 */
public class MarkovString extends TimerTask {
    
    private HashMap<String, MarkovNode> nodes;
    /** Creates a new instance of MarkovString */
    public MarkovString() {
        
        File f = new File("dict");
        nodes = new HashMap<String, MarkovNode>();

        nodes.put("[", new MarkovNode("["));
        nodes.put("]", new MarkovNode("]"));

        if (f.exists())
        {
            try {
                FileReader fr = new FileReader(f);
                BufferedReader i = new BufferedReader(fr);
                String s;

                    while ((s = i.readLine()) != null)
                    {
                        String[] ss = s.trim().split(",");
                        MarkovNode a, b;
                        if (!nodes.containsKey(ss[0]))
			{
                            a = new MarkovNode(ss[0]);
			    nodes.put(ss[0], a);
			}
                        else 
                            a = nodes.get(ss[0]);
                        
                        if (!nodes.containsKey(ss[1]))
			{
                            b = new MarkovNode(ss[1]);
			    nodes.put(ss[1], b);
			}
                        else
                            b = nodes.get(ss[1]);
                        
                        a.AddChild(b);
                    }
                
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        Timer t = new Timer();
        t.schedule(this, 0, 300000);
    }
    
    public void run()
    {
        Save();
    }
    
    public void Save()
    {
        FileWriter w;
        try {
            w = new FileWriter("dict");
        
        BufferedWriter r = new BufferedWriter(w);
        
        for (MarkovNode n : nodes.values())
        {
            for (MarkovNode c : n.getChildren())
            {
                r.write(n.getWord() + "," + c.getWord() + "\n");
            }
        }

		r.flush();
        	r.close();

		w.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
	
    }
    
    public void Learn(String sentence)
        {
            StringBuffer sb = new StringBuffer();
            for (char c :  sentence.toCharArray())
            {
                if (Character.isWhitespace(c))
                    sb.append(" ");
                else if (Character.isLetterOrDigit(c))
                    sb.append(Character.toLowerCase(c));
            }

            String[] words = sb.toString().split(" ");
            String lastWord = null;
            for (String word : words)
            {
		if (word.trim().equals("")) continue;
                MarkovNode n, parent;
                if (!nodes.containsKey(word))
                {
                    n = new MarkovNode(word);
                    nodes.put(word, n);
                }
                else
                    n = nodes.get(word);

                if (lastWord == null)
                    parent = nodes.get("[");
                else
                    parent = nodes.get(lastWord);

                parent.AddChild(n);
                lastWord = word;
            }

            nodes.get(lastWord).AddChild(nodes.get("]"));
        }

        public String Generate()
        {
            StringBuffer sb = new StringBuffer();
            MarkovNode current = nodes.get("[");
            while (current.getWord() != "]")
            {
                current = current.GetRandomNode();
                sb.append(current.getWord());
                sb.append(" ");
            }
            return sb.toString().replace("]", " ").trim();
        }
}
